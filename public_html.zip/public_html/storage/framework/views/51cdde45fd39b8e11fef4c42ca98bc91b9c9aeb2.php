

<?php $__env->startSection('content'); ?>
<div class="wrapper Play-Now-wrapper" style="height: 100%;">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="login-form-wrapper">
                    <input type="hidden" name="active-leaderboad-single" id="active-leaderboad-single" value="<?php echo e((!empty($leaderboard->active) && $leaderboard->active==1) ? $leaderboard->id : ''); ?>">
                    <div class="login-form">
                        <div class="login-logo  text-center mb-5">
                         <h3 class="Price-Amount-heading giveaway">Log in to see our live leaderboard giveaway</h3>
                        </div>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="login-input-group">
                                <input id="email" type="email" placeholder="Email" class="login-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>"  autocomplete="email" required autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="login-input-group">
                                <input id="password" type="password" placeholder="Password" class="login-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"  autocomplete="current-password" required>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                           
                            <div class="login-input-group " style="display: none;">
                                <input id="instagramUsername" type="text" placeholder="instagram Username" class="<?php $__errorArgs = ['instagramUsername'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="instagramUsername" value="<?php echo e(old('instagramUsername')); ?>"  autocomplete="name" autofocus>
                                <?php $__errorArgs = ['instagramUsername'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="login-input-group text-center submit-input">
                                <button type="submit" class="login-submit">
                                    <?php echo e(__('Login')); ?>

                                </button>
                            </div>
                        </form>
                        <div class="login-form-Forgot text-center">
                            <a href="<?php echo e(route('password.request')); ?>" class="login-Forgot text-white"><u>Forgot Password?</u></a>
                        </div>
                        <div class="mt-5 login-form-Forgot text-center">
                            <p>
                                Don't have an account? <a href="<?php echo e(route('register')); ?>" class="login-to-Sign"><u>Sign up</u></a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="row leaderboard-search" style="padding: 0px;">
                    <div class="col-md-12 text-center">
                        <h4>THE LIVE LEADERBOARD</h4>
                    </div>
                </div>
            </div>
            <div class="col-12 text-center">
                <div class="leaderboard-table" id="leaderboard-table">
                    <div class="row leaderboard-bar-table table-title-bar m-0">

<div class="col-3 text-left">

<div class="prize">

<h4>Position</h4>

</div>

</div>

<div class="col-3">

<div class="name text-left">

<h4>Username</h4>

</div>

</div>

<div class="col-6 text-right">

<div class="points">

<h4>Mentions</h4>

</div>

</div>

</div>

                    <?php if(!empty($leaderboard->post_mentions)): ?>
                        <?php
                        $color_array = array('light-bg', 'dark-orange', 'light-bg dark-orange');
                        $k = count($color_array);
                        $i=0;
                        $p=1;
                        $FinalMentions=$leaderboard->post_mentions;
                        ?>

                        <?php $__currentLoopData = $FinalMentions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Mentions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $class= $color_array[$i % $k];
                            ?>
                            <div class="row leaderboard-details mentions-row <?php echo e($class); ?> m-0 data-row ownerId_<?php echo e($Mentions->ownerId); ?>"  data-username="<?php echo e($Mentions->ownername); ?>" data-mention="<?php echo e($Mentions->totalMentiones); ?>" >
                                <div class="col-3 text-left">
                                    <div class="prize">
                                        <h4 class="poition-no"><?php echo e($p); ?></h4>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="name">
                                        <div class="account">
                                            <div class="table-avatar">
                                                <img class="mr-2" src="<?php echo e($Mentions->ownername_profile_pic_url); ?>" alt="">
                                                <span><h4><?php echo e($Mentions->ownername); ?></h4></span>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-6 text-right">
                                    <div class="points">
                                        <h4 id="total_mentions_<?php echo e($Mentions->ownerId); ?>"><?php echo e($Mentions->totalMentiones); ?></h4>
                                    </div>
                                </div>
                            </div>
                            <?php
                            $i++;
                            $p++;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
The Leaderboard - Log in to your account
<?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?>
Log in to your live Leaderboard account to and win amazing prizes today
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/theleaderboard/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>
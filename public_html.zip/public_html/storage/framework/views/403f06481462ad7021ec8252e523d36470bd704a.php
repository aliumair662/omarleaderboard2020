<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="container-fluid site-wrapper front-screen-height">
        <div class="row">
            <div class="col-12">
                <div class="Payment-Method-header">
                    <div class="row">
                        <div class="col-md-4">
                            <!-- <div class="Wallet_btn">
                                <a href="<?php echo e(route('logout')); ?>" class="Wallet"><b class="Wallet-Back">Exit Game</b></a>
                            </div> -->
                            <div class="prize-button exit-button">
								<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><button class="btn"><i class="fa fa-sign-out-alt"></i>Exit Game</button></a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
							</div>
                            
                        </div>
                    </div>
                </div>
                <div class="price-amount-wrapper mini-price-amount-wrapper">
                    <div class="login-form-wrapper Play-Now-wrapper">
                        <div class="login-form">
                            <div class="login-logo text-center">
                                <p class="mb-1 Manage-competition-text">There is no currently <br> no leaderboard giveaways live</p>
                                <p class="mb-3">Please come back soon!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/theleaderboard/public_html/resources/views/leaderboard/noleaderboard.blade.php ENDPATH**/ ?>
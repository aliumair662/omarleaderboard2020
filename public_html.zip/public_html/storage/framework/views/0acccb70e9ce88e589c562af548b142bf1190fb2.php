<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'BOOM')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <!-- Styles -->
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
    <!-- Fonts -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('style.css')); ?>">
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Droid+Sans:400,700">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
</head>
<body>
    <div id="app">
        <header>
            <div class="container-fluid site-wrapper">
                <div class="row header-row">
                    <div class="col-12 text-center">
                        <img src="<?php echo e(asset('assets/logos/logo.png')); ?>" height="40">
                    </div>
                    <!-- <div class="col-6 avatar-casino">
                        <?php if(auth()->guard()->guest()): ?>
                        <?php else: ?>
                            <span class="casino-user mr-2">Hello<span class="ml-2"><?php echo e(Auth::user()->name); ?></span>
                        </span>
                        <?php endif; ?>
                            <?php if(auth()->guard()->guest()): ?>
                                <?php if(Route::has('register')): ?>
                                <?php endif; ?>
                            <?php else: ?>

                            <div class="logout-button">
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">logout</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                            <?php endif; ?>


                    </div> -->
                </div>
            </div>

        </header>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <footer>
          <div class="container-fluid site-wrapper">
                <div class="row">
                    <div class="col-12 text-center">
                       <p>©️ 2021 The Leaderboard</p>
                    </div>
                    <div class="col-12 text-center d-flex justify-content-center mt-2 mb-2">
                        <div class="language-selector">
                           <!-- <select data-placeholder="Choose a Language...">
                            <option value="AF">Afrikaans</option>
                            <option value="SQ">Albanian</option>
                            <option value="AR">Arabic</option>
                            <option value="HY">Armenian</option>
                            <option value="EU">Basque</option>
                            <option value="BN">Bengali</option>
                            <option value="BG">Bulgarian</option>
                            <option value="CA">Catalan</option>
                            <option value="KM">Cambodian</option>
                            <option value="ZH">Chinese (Mandarin)</option>
                            <option value="HR">Croatian</option>
                            <option value="CS">Czech</option>
                            <option value="DA">Danish</option>
                            <option value="NL">Dutch</option>
                            <option value="EN">English</option>
                            <option value="ET">Estonian</option>
                            <option value="FJ">Fiji</option>
                            <option value="FI">Finnish</option>
                            <option value="FR">French</option>
                            <option value="KA">Georgian</option>
                            <option value="DE">German</option>
                            <option value="EL">Greek</option>
                            <option value="GU">Gujarati</option>
                            <option value="HE">Hebrew</option>
                            <option value="HI">Hindi</option>
                            <option value="HU">Hungarian</option>
                            <option value="IS">Icelandic</option>
                            <option value="ID">Indonesian</option>
                            <option value="GA">Irish</option>
                            <option value="IT">Italian</option>
                            <option value="JA">Japanese</option>
                            <option value="JW">Javanese</option>
                            <option value="KO">Korean</option>
                            <option value="LA">Latin</option>
                            <option value="LV">Latvian</option>
                            <option value="LT">Lithuanian</option>
                            <option value="MK">Macedonian</option>
                            <option value="MS">Malay</option>
                            <option value="ML">Malayalam</option>
                            <option value="MT">Maltese</option>
                            <option value="MI">Maori</option>
                            <option value="MR">Marathi</option>
                            <option value="MN">Mongolian</option>
                            <option value="NE">Nepali</option>
                            <option value="NO">Norwegian</option>
                            <option value="FA">Persian</option>
                            <option value="PL">Polish</option>
                            <option value="PT">Portuguese</option>
                            <option value="PA">Punjabi</option>
                            <option value="QU">Quechua</option>
                            <option value="RO">Romanian</option>
                            <option value="RU">Russian</option>
                            <option value="SM">Samoan</option>
                            <option value="SR">Serbian</option>
                            <option value="SK">Slovak</option>
                            <option value="SL">Slovenian</option>
                            <option value="ES">Spanish</option>
                            <option value="SW">Swahili</option>
                            <option value="SV">Swedish </option>
                            <option value="TA">Tamil</option>
                            <option value="TT">Tatar</option>
                            <option value="TE">Telugu</option>
                            <option value="TH">Thai</option>
                            <option value="BO">Tibetan</option>
                            <option value="TO">Tonga</option>
                            <option value="TR">Turkish</option>
                            <option value="UK">Ukrainian</option>
                            <option value="UR">Urdu</option>
                            <option value="UZ">Uzbek</option>
                            <option value="VI">Vietnamese</option>
                            <option value="CY">Welsh</option>
                            <option value="XH">Xhosa</option>
                            </select> -->
                            <div id="google_translate_element"></div>
                        </div>
                        <div class="insta-feed ml-3">
                            <a href="https://www.instagram.com/theleaderboard.io/">
                             <i class="fab fa-instagram"></i>
                            </a>
                        </div>


                    </div>
                    <div class="col-12 text-center">
                        <p class="footer-infotext">TheLeaderboard.io is a decentralised gaming platform. Players can win cash prizes by playing The Leaderboard games. All games are based on skill and not by chance. We are not regulated by the gambling commission. </p>
                    </div>
                </div>
            </div>
        </footer>
    </div>


    <!-- CDNS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?>">
   <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    <!-- CDNS -->

    <script>

        $( document ).ready(function() {
            sortMentionRow();
            if($("#active-leaderboad-single").val()!=''){
                setInterval(function(){ getSinglelatestMentionBoard(); }, 10000);

            }

        });


        function sortMentionRow(){
            var store = [];
            $( ".mentions-row" ).each(function( i ) {
                var sortnr = parseFloat($(this).attr("data-mention"));
                if(!isNaN(sortnr)) store.push([sortnr, $(this)]);
            });
            store.sort(function(x,y){
                // return x[0] - y[0];
                return y[0] - x[0];
            });
            var len=store.length;
            var p=1;
            var colorclass='';
            for(var i=0; i<len; i++){
                if(p>=1 && p<=3){
                    colorclass='light-bg';
                }else if (p>=4 && p<=10){
                    colorclass='dark-orange';
                }else{
                    colorclass='dark-red';
                }
                $(store[i][1]).removeClass('light-bg');
                $(store[i][1]).removeClass('dark-orange');
                $(store[i][1]).removeClass('dark-red');
               $(store[i][1]).addClass(colorclass);
                //console.info(store[i][1]);
                $("#leaderboard-table").append(store[i][1]);
                p++;
            }
            store = null;


            $('.poition-no').each(function(idx, elem){

                $(elem).text(idx+1);
            });
            //whatismyPosition();
        }
        function whatismyPosition(){

            var total_position=$('.mentions-row').length;
            var myposition=0;
            if($('#instagramid').val()!=''){
                console.info('ownerId_'+$('#instagramid').val());
                if($('.mentions-row').hasClass('ownerId_'+$('#instagramid').val())){
                    console.info("my position exit");
                    myposition=$('.ownerId_'+$('#instagramid').val()).find('.poition-no').text();
                    $("#notonlederboard").addClass('d-none');
                    $("#onlederboard").removeClass('d-none');
                    $(".skip-to-me").removeClass('d-none');
                    $("#myposition").text(ordinal_suffix_of(myposition));
                    $("#total-position").text(total_position);
                }else{
                    $("#notonlederboard").removeClass('d-none');
                    $("#onlederboard").addClass('d-none');
                    $(".skip-to-me").addClass('d-none');

                }

            }else{
                $("#notonlederboard").removeClass('d-none');
                $("#onlederboard").addClass('d-none');

            }


        }
        function ordinal_suffix_of(i) {
            var j = i % 10,
                k = i % 100;
            if (j == 1 && k != 11) {
                return i + "st";
            }
            if (j == 2 && k != 12) {
                return i + "nd";
            }
            if (j == 3 && k != 13) {
                return i + "rd";
            }
            return i + "th";
        }
        /*Get Post Updated Data*/
        function getSinglelatestMentionBoard(){
            var route='/latestMentionBoard';
            $.ajax({
                url: route,
                type: 'POST',
                data: {
                    'id':$("#active-leaderboad-single").val(),
                    '_token': '<?php echo e(csrf_token()); ?>',
                },
                success: function(response) {
                    if(response.code==200){
                        var Allmentions=response.mentions;
                        var html='';
                        for (var i = 0; i < Allmentions.length; i++) {
                            var mention=Allmentions[i];

                            if($(".mentions-row").hasClass("ownerId_"+mention.ownerId)){
                                $("#total_mentions_"+mention.ownerId).text(mention.totalMentiones);
                                $('.ownerId_'+mention.ownerId).attr('data-mention',mention.totalMentiones);
                            }else{

                                html+='<div class="row leaderboard-details mentions-row m-0 ownerId_'+mention.ownerId+'" data-id="'+mention.ownerId+'" data-mention="'+mention.totalMentiones+'">';
                                html+='<div class="col-3">';
                                html+='<div class="prize">';
                                html+='<h4 class="poition-no"></h4>';
                                html+='</div>';
                                html+='</div>';

                                html+='<div class="col-3">';
                                html+='<div class="name">';
                                html+='<div class="account">';
                                html+='<div class="table-avatar">';
                                html+='<img class="mr-2" src="'+mention.ownername_profile_pic_url+'" alt="">';
                                html+='<span><h4>'+mention.ownername+'</h4></span>';
                                html+='</div>';
                                html+='</div>';
                                html+='</div>';
                                html+='</div>';

                                html+='<div class="col-6 text-right">';
                                html+='<div class="points">';
                                html+='<h4 id="total_mentions_'+mention.ownerId+'">'+mention.totalMentiones+'</h4>';
                                html+='</div>';
                                html+='</div>';
                                html+='</div>';

                            }

                        }
                        if(html!=''){
                            $("#leaderboard-table").append(html);
                        }
                        if(response.myposition!=''){
                           var  myposition=response.myposition;
                           var  totalposition=response.totalposition;
                            $("#notonlederboard").addClass('d-none');
                            $("#onlederboard").removeClass('d-none');
                            $(".skip-to-me").removeClass('d-none');
                            $("#myposition").text(ordinal_suffix_of(myposition));
                            $("#total-position").text(totalposition);
                        }else{
                            $("#notonlederboard").removeClass('d-none');
                            $("#onlederboard").addClass('d-none');
                            $(".skip-to-me").addClass('d-none');

                        }
                        if(response.awaymessage!=''){
                            $("#away_message").removeClass('d-none');
                            $("#away_message").find('p').text(response.awaymessage);
                        }else{
                            $("#away_message").find('p').text('');
                            $("#away_message").addClass('d-none');
                        }
                        sortMentionRow();
                    }

                },
            });
        }


        function searchUser() {
            // Declare variables
            var input = document.getElementById("keyword");
            var filter = input.value.toLowerCase();
            var table = document.getElementById("leaderboard-mentions-section");
            var div = table.getElementsByClassName("data-row");
            var filtered=false;
            // Loop through all table rows, and hide those who don't match the search query
            for (i = 0; i < div.length; i++) {
                var username = div[i].getAttribute("data-username");
                console.info(username+"=="+filter);
                if (username.toLowerCase().indexOf(filter) > -1) {
                    filtered = true;
                }
                if(filtered===true) {
                    div[i].style.display = '';
                }
                else {
                    console.info("notmatc");
                    console.info(div[i]);
                    div[i].style.display = 'none';
                }
            }

        }



        </script>
        <script type="text/javascript">
/*function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}*/
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

</body>
</html>
<?php /**PATH /home/logitech99/public_html/leaderboard/resources/views/layouts/app.blade.php ENDPATH**/ ?>
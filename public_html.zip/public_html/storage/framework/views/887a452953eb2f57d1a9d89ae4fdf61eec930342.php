<?php $__env->startSection('content'); ?>

    <?php if(!empty($leaderboard)): ?>



        <input type="hidden" name="active-leaderboad-single" id="active-leaderboad-single" value="<?php echo e((!empty($leaderboard->active) && $leaderboard->active==1) ? $leaderboard->id : ''); ?>">

        <input type="hidden" name="instagramid" id="instagramid" value="<?php echo e(Auth::user()->instagramid); ?>">

        <div class="wrapper" id="user_leaderboard" data-id="<?php echo e($leaderboard->id); ?>" data-endtime="<?php echo e($leaderboard->leaderboard_end_date); ?>">

            <div class="container-fluid site-wrapper">

                <div class="row m-0">

                    <div class="col-12 col-md-12 order-md-2 order-2 mobile-leaderboard">

                        <div class="Payment-Method-header leaderboard-header position-relative">

                            <div class="row">

                            <div class="col-md-3 col-3 order-md-1 desktop order-1 text-left">
								<div class="prize-button exit-button">
								<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><button class="btn"><i class="fa fa-sign-out-alt"></i>Exit Game</button></a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
								</div>
                            </div>

                                <div class="col-md-6 col-6 order-md-2 order-2 casino-timer leaderboard-timer text-center counter-width">

                                    <div class="row counter-width">

                                        <div class="col-12">

                                            <p>COMPETITION ENDS IN</p>

                                        </div>

                                        <div class="col-3 days"><h3 id="days">05</h3><p>Days</p></div>

                                        <div class="col-3 hours"><h3 id="hours">12</h3><p>Hours</p></div>

                                        <div class="col-3 mins"><h3 id="mins">26</h3><p>Mins</p></div>

                                        <div class="col-3 secs"><h3 id="secs">05</h3><p>Secs</p></div>

                                    </div>

                                </div>

                                <div class="col-md-3 col-3 order-3 order-md-3 prize-table text-right">

                                    <div class="prize-button">

                                        <button class="btn"><i class="fa fa-gift"></i><a href="https://www.instagram.com/s/aGlnaGxpZ2h0OjE3ODU1MDg1OTExNDY4MDI3?igshid=wu57rjjq2cco&story_media_id=2504848121957656095" target="_blank" style="color: white">See Prizes</a></button>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="col-12 col-md-12 order-md-3 order-3 mobile-leaderboard">

                        <div class="leaderboard-bar">
                             <?php if(!empty($leaderboard->myposition)): ?>
                           <p id="onlederboard" >You are <span class="mr-1 ml-1" id="myposition"><?php echo e($leaderboard->myposition); ?></span> out of <span id="total-position"><?php echo e($leaderboard->totalposition); ?></span> players</p>
                            <?php else: ?>
                                <p id="notonlederboard">You're not on live leaderboard, start tagging your friends to appear in live leaderboard.</p>
                            <?php endif; ?>
                        </div>

                        <div class="leaderboard-bar <?php echo e(!empty($leaderboard->awaymessage) ?  : 'd-none'); ?>" id="away_message">
                            <?php if(!empty($leaderboard->awaymessage)): ?>
                                <p ><?php echo e($leaderboard->awaymessage); ?></p>
                            <?php endif; ?>
                        </div>


                    </div>

                    <div class="col-12 col-md-6 order-md-4 order-6">

                        <div class="row work-part leaderboard-work post-section">

                            <div class="col-6">

                                <h4>ENTRY POST</h4>

                            </div>
                            <div class="col-6 text-right mb-1">
                                <div class="how-it-works" data-toggle="modal" data-target="#gamerule1">
                                        <a href="#"><button type="link">How It Works</button></a>
                                </div>
                            </div>

                            <div class="col-12 iframe-box position-relative">

                                <div id="myCarousel" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->

                                    <div class="carousel-inner">



                                                <div class="carousel-item active">

                                                  <?php echo $leaderboard->media; ?>

                                                </div>


                                    </div>



                                </div>





                            </div>

                            <div class="how-it-works tag-friends">
                                <button type="link">
                                    <a href="<?php echo e($leaderboard->post_url); ?>">Tag Friends Now</a>
                                </button>

                            </div>

                        </div>

                    </div>

                    <div class="col-12 col-md-6 order-md-5 order-4 leaderboard-spacing mobile-leaderboard">

                    <div class="leaderboard-bar">

                        <h3>Leaderboard- Top 100</h3>

                    </div>

                    <div class="show-table rotate-image" >

                        <img src="assets/logos/Group 88.svg" alt="">

                    </div>
                    <div class="col-12 col-md-6 order-md-6 order-5 leaderboard-container position-relative" id="mytable">

<div class="user-tbl">

    <div class="row leaderboard-bar-table  table-title-bar m-0">

        <div class="col-3">

            <div class="prize">

                <h4>Position</h4>

            </div>

        </div>

        <div class="col-3">

            <div class="name">

                <h4>Username</h4>

            </div>

        </div>

        <div class="col-6 text-right">

            <div class="points">

                <h4>Mentions</h4>

            </div>

        </div>

    </div>

    <div class="leaderboard-table" id="leaderboard-table">

        <?php if(!empty($leaderboard->post_mentions)): ?>

            <?php

            /**dark-orange => orange **/
            /**light-bg => green **/
            $color_array = array('light-bg', 'dark-orange', 'dark-red');

            $k = count($color_array);

            $i=0;

            $p=1;

            $FinalMentions=$leaderboard->post_mentions;
            $class='dark-red';
            ?>



            <?php $__currentLoopData = $FinalMentions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Mentions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    if($p>=1 && $p<=3){
                        $class='light-bg';
                    }elseif ($p>=4 && $p<=10){
                        $class='dark-orange';
                    }else{
                        $class='dark-red';
                    }
              //  $class= $color_array[$i % $k];

                ?>

                <div class="row leaderboard-details mentions-row <?php echo e($class); ?> m-0 data-row ownerId_<?php echo e($Mentions->ownerId); ?>"  data-username="<?php echo e($Mentions->ownername); ?>" data-mention="<?php echo e($Mentions->totalMentiones); ?>" >

                    <div class="col-3">

                        <div class="prize">

                            <h4 class="poition-no"><?php echo e($p); ?></h4>

                        </div>

                    </div>

                    <div class="col-3">

                        <div class="name">

                            <div class="account">

                                <div class="table-avatar">

                                    <img class="mr-2" src="<?php echo e($Mentions->ownername_profile_pic_url); ?>" alt="">

                                    <span><h4><?php echo e($Mentions->ownername); ?></h4></span>

                                </div>

                            </div>



                        </div>

                    </div>



                    <div class="col-6 text-right">

                        <div class="points">

                            <h4 id="total_mentions_<?php echo e($Mentions->ownerId); ?>"><?php echo e($Mentions->totalMentiones); ?></h4>

                        </div>

                    </div>

                </div>

                <?php

                $i++;

                $p++;

                ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>

    </div>
     <div class="col-12 col-md-12 order-md-5 order-7 leaderboard-container skip-to-me-desktop-section">
        <div class="row leaderboard-search user-search">
            <div class="col-sm-12">
                <!--<div class="how-it-works skip-to-me skip-to-me-desktop skip-me-btn d-none <?php echo e((Auth::user()->instagramid != '') ?  : 'd-none'); ?>" style="display: none">
                    <button>Skip To Me</button>
                </div>-->
            </div>
        </div>
    </div>
    <div class="col-12 col-md-12">
          <div class="row">
            <div class="col-6 col-sm-6  d-none d-md-none">
                <div class="how-it-works see-post"> <button>See Post</button></div>
            </div>
            <div class="col-12 col-sm-12 d-flex pt-2 pb-2 playing" style="justify-content: flex-end;">
            <div class="how-it-works d-none d-md-none d-sm-block d-block playings">

                        <a href="#" class="see-post"> <button type="link">Continue Playing</button></a>

                </div>
            <!--<div class="how-it-works skip-to-me skip-to-me-mobile <?php echo e((Auth::user()->instagramid != '') ?  : 'd-none'); ?>">
                <button>Skip To Me</button>
             </div>-->
            </div>
        </div>

    </div>

</div>

</div>

                </div>

            </div>

        </div>

        </div>

    <?php endif; ?>

    <div class="modal fade" id="gamerule1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">

            <div class="modal-content">

                <div class="modal-header">

                    <h5 class="gamerule modal-title" id="exampleModalLongTitle">How It Works</h5>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                        <span aria-hidden="true">&times;</span>

                    </button>

                </div>

                <div class="modal-body">

                   <?php echo $leaderboard->how_it_works;?>

                </div>



            </div>

        </div>

    </div>

    <script   type="text/javascript">



        if($("#active-leaderboad-single").val()!=''){

            var id=$("#active-leaderboad-single").val();

            var countDownDate=$("#user_leaderboard").attr("data-endtime");

            ManageCounter(true,countDownDate);

        }

        var intervalID = null;

        function ManageCounter(flag,countDownDate){

            // Set the date we're counting down to
                console.info(countDownDate);


            var countDownDate = new Date(countDownDate).getTime();
            console.info(countDownDate);
            // Update the count down every 1 second
            if(flag){

                intervalID = setInterval(function() {

                    // Get today's date and time

                    var now = new Date().getTime();

                    // Find the distance between now and the count down date

                    var distance = countDownDate - now;

                    // Time calculations for days, hours, minutes and seconds

                    var days = Math.floor(distance / (1000 * 60 * 60 * 24));

                    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

                    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));

                    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                    // Output the result in an element with id="demo"

                    var leaderboard_post_wrapper=$("#user_leaderboard");

                    leaderboard_post_wrapper.find("#days").text(days);

                    leaderboard_post_wrapper.find("#hours").text(hours);

                    leaderboard_post_wrapper.find("#mins").text(minutes);

                    leaderboard_post_wrapper.find("#secs").text(seconds);

                    /*document.getElementById("demo").innerHTML = days + "d " + hours + "h "

                    + minutes + "m " + seconds + "s ";*/

                    // If the count down is over, write some text

                    if (distance < 0) {

                        clearInterval(intervalID);

                        document.getElementById("demo").innerHTML = "EXPIRED";

                    }

                }, 1000);

            }

        }

    </script>

    <script>



        $(".show-table").click(function(e){
            e.preventDefault();
            if($("#mytable").hasClass("d-none")){
                $("#mytable").removeClass("d-none");
                $(this).removeClass('rotate-image-360');
                $(this).addClass('rotate-image');
                $(".work-part").addClass('post-section');
            }else{
                $("#mytable").addClass("d-none");
                $(this).removeClass('rotate-image');
                $(this).addClass('rotate-image-360');
                $(".work-part").removeClass('post-section');
            }
                });

$(".see-post").click(function(e){
            e.preventDefault();

            if($( window ).width()<=767){
                if($("#mytable").hasClass("d-none")){
                $("#mytable").removeClass("d-none");
                $(".show-table").removeClass('rotate-image-360');
               $(".show-table").addClass('rotate-image');
                $(".work-part").addClass('post-section');
            }else{
                $("#mytable").addClass("d-none");
                $(".work-part").removeClass('post-section');
                $(".show-table").removeClass('rotate-image');
               $(".show-table").addClass('rotate-image-360');
            }
            }else{
                 $('html, body').animate({
        scrollTop: $(".post-section").offset().top
    }, 2000);
            }

                });


        $(".skip-to-me").click(function() {
    $('html, body').animate({
        scrollTop: $(".ownerId_"+$("#instagramid").val()).offset().top
    }, 2000);
});

    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/logitech99/public_html/leaderboard/resources/views/home.blade.php ENDPATH**/ ?>